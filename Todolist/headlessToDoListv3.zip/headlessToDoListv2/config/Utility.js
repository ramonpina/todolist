const { versionSchema } = require("../schemas/Version");
const mongoose = require('mongoose');

let Version = mongoose.model("Version", versionSchema);
let firstVersion = new Version({_id: 1, version: 1, taskCounter: 1});

const crearDB = () => {
    firstVersion.save();
}

async function getDatabaseVersion() {
    
    let id;

    // Get DB details
    await Version.findOne( function(err, databaseVersion) {
        if (err) {
            console.log(err);
            response.sendStatus(500);
            return;
        } else {
            id = databaseVersion.version;
        }
    });
    
    return id;
}

function updateDatabaseVersion() {
    // Get DB details
    Version.findOne( function(err, databaseVersionBeforeUpdate) {
        if (err) {
            console.log(err);
            response.sendStatus(500);
            return;
        } else {
            // Update DB details
            Version.updateOne({_id: 1}, {version: ++databaseVersionBeforeUpdate.version}, function(err) {
                if (err) {
                    console.log(err + "[Database couldn't be updated]");
                    return;
                } else {
                    console.log("[Successfully updated the database]");
                }
            });
        }
    });
}

async function getTaskVersion(taskID, ItemModel) {
    
    let version;

    // Get DB details
    await ItemModel.findOne({_id: taskID}, function(err, item) {
        if (err) {
            console.log(err);
            response.sendStatus(500);
            return;
        } else {
            version = item.Version;
        }
    });
    
    return version;
}

function increaseTaskCounter() {
    // Get DB details
    Version.findOne( function(err, databaseBeforeUpdate) {
        if (err) {
            console.log(err);
            response.sendStatus(500);
            return;
        } else {
            // Update DB details
            Version.updateOne({_id: 1}, {taskCounter: ++databaseBeforeUpdate.taskCounter}, function(err) {
                if (err) {
                    console.log(err + "[Task Counter couldn't be updated]");
                    return;
                } else {
                    console.log("[Successfully updated the Task Counter]");
                }
            });
        }
    });
}

async function assignTaskID() {

    let id;

    // Get DB details
    await Version.findOne( function(err, databaseBeforeUpdate) {
        if (err) {
            console.log(err);
            response.sendStatus(500);
            return;
        } else {
            id = databaseBeforeUpdate.taskCounter;
        }
    });

    return id;
}

function validateDatabaseHasBeenModified(versionInDatabase, request) {
    if ("cookies" in request){
        const { cookies } = request; // Get cookies from client
        if ("version" in cookies) {
            if (versionInDatabase === +cookies.version) {
                return true;
            } else {
                return false;
            }
        }
    } 

    return false;
}

module.exports = {crearDB, getDatabaseVersion, getTaskVersion, updateDatabaseVersion, validateDatabaseHasBeenModified, assignTaskID, increaseTaskCounter}