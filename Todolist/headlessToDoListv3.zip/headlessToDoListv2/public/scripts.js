//DOM Objects
const container = document.getElementById('listContainer');
const table = document.getElementById('body');
const buttonCreate = document.getElementById('crearTarea');
const buttonUpdate = document.getElementById('guardarAct');
const updateListButton = document.getElementById('updateList');

let eliminar = document.getElementsByClassName('eliminar');
let editar = document.getElementsByClassName('editar');

let lastVersion = localStorage.getItem('lastVersion') || -1;

let Connected = true;
let contador = 0;

const handleConnectionChange = (event) => {
  if(event.type == "offline"){
    Connected = false;
  }
  if(event.type == "online"){
    Connected = true;
    let inserter = 0;
    if(localStorage.length != 0){
      while(inserter < localStorage.length){
        axios.post('/items',{headers: {'If-None-Match': lastVersion}},JSON.parse(localStorage.getItem(`toInsert${inserter}`)))
        .then(() => {
          localStorage.setItem('lastVersion',+lastVersion+1);
          inserter++
        });
      }
      localStorage.clear();
      contador = 0;
    }
  }
}

window.addEventListener('online', handleConnectionChange);
window.addEventListener('offline', handleConnectionChange);

const createValues = (tasks) => {
  let fragment = document.createDocumentFragment();
  for(let i = 0; i < tasks.length; i++){
      let tr = document.createElement('tr');
      let id = document.createElement('th');
      let description = document.createElement('th');
      let dueDate = document.createElement('th');
      let status = document.createElement('th');
      let action = document.createElement('th');
      action.innerHTML = `<span class="editar ${tasks[i]._id}" data-toggle="modal" data-target="#actualizarTask">Editar</span> <span class="eliminar ${tasks[i]._id}">Eliminar</span>`
      id.textContent = tasks[i]._id;
      description.textContent = tasks[i].Description;
      dueDate.textContent = tasks[i].dueDate.substring(0,10);
      status.textContent = tasks[i].State;
      tr.appendChild(id);
      tr.appendChild(description);
      tr.appendChild(dueDate);
      tr.appendChild(status);
      tr.appendChild(action);
      fragment.appendChild(tr);
  }
  return fragment;
}

buttonCreate.addEventListener('submit',(e)=> {
  e.preventDefault();
  let Status = document.getElementById('Status');
  let createObject = {
    Description: document.getElementById('Description').value,
    dueDate: document.getElementById('dueDate').value,
    State: Status.options[Status.selectedIndex].text
  };
  if(Connected == true){
    axios.post('items',createObject,{headers: {'If-None-Match': lastVersion}}).then(function (response) {
      alert('Creado todo bien');
      localStorage.setItem('lastVersion',+lastVersion+1);
    })
    .catch(function (error) {
      alert('Hubo un error');
      console.log(error);
      console.log(lastVersion);
    });
  }
  else{
    localStorage.setItem(`toInsert${contador}`,JSON.stringify(createObject));
    contador++;
  }
})

const updateTarea = (recurso) => {
let Status = document.getElementById('StatusAct');
let updateObject = {
    Description: document.getElementById('DescriptionAct').value,
    dueDate: document.getElementById('dueDateAct').value,
    State: Status.options[Status.selectedIndex].text
};
axios.put('/items/' + recurso, updateObject,{headers: {'If-None-Match': lastVersion}})
.then(()=> {
  alert('Se modiico bien');
  localStorage.setItem('lastVersion',+lastVersion+1);
})
.catch('Hubo un error, intentelo de nuevo')
};

updateListButton.addEventListener('click', ()=>{
      axios.get('/items',{headers: {'If-None-Match': lastVersion}}).then((res) => {
        localStorage.setItem('lastVersion', res.headers.etag);
        lastVersion = localStorage.getItem('lastVersion') 
        let tasks = res.data.tasks;
        let append = createValues(tasks);
        table.innerHTML = "<tr id='atributos'><th>ID</th><th>Description</th><th>Due date</th><th>Status</th><th>Action<th></tr>"
        table.appendChild(append);
      })
})

axios.get('/items',{headers: {'If-None-Match': +lastVersion-1}})
  .then((response) => {
    let tasks = response.data.tasks;
    let append = createValues(tasks);
    table.appendChild(append);

    eliminar = Array.from(eliminar);
    editar = Array.from(editar);

    eliminar.forEach(element => {
      element.addEventListener('click',()=>{
          let recurso = element.className.split(' ')[1];
          console.log('dj');
          axios.delete('/items/'+ recurso,{headers: {'If-None-Match': lastVersion}})
          .then(() => {
          alert('Se elimino bien');
          localStorage.setItem('lastVersion',+lastVersion+1);
        });
      })    
    });

    editar.forEach(element => {
      element.addEventListener('click', ()=>{
        let recurso = element.className.split(' ')[1];
        buttonUpdate.addEventListener('submit',(e)=>{
          e.preventDefault();
          updateTarea(recurso);
      })
      })
    })
  })
  .catch((error) => {
    console.log(error);
  });
